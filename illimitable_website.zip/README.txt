# ILLIMITABLE website

Open `index.html` in a browser. It is a responsive static storefront with:
- product showcase using the supplied tracksuit mockup
- responsive mobile layout
- size selection
- working Add to Bag interaction
- smooth navigation
- no backend required

For real checkout/orders, connect the Add to Bag button to your preferred ecommerce/payment backend.
